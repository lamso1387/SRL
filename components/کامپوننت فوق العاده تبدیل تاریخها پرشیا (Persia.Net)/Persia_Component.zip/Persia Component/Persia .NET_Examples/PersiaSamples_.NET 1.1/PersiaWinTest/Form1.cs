using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PersiaWinTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MonthCalendar monthCalendar1;
		private System.Windows.Forms.Label lblSimple;
		private System.Windows.Forms.Button btnConvertToPersian;
		private System.Windows.Forms.Label lblPersian;
		private System.Windows.Forms.Label lblWeekday;
		private System.Windows.Forms.TextBox txtYear;
		private System.Windows.Forms.TextBox txtMonth;
		private System.Windows.Forms.TextBox txtDay;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox comboMonth;
		private System.Windows.Forms.TextBox txtSetYear;
		private System.Windows.Forms.Label lbl2;
		private System.Windows.Forms.Label lbl3;
		private System.Windows.Forms.Label lbl1;
		private System.Windows.Forms.ComboBox comboDays;
		private System.Windows.Forms.Button btnConvertToGregorian;
		private System.Windows.Forms.Label lblGregorian;
		private System.Windows.Forms.Button btnClose;
		private System.Windows.Forms.Label lblLeap;
		private System.Windows.Forms.Label lblYear;
		private System.Windows.Forms.Button btnConvertToIslamic;
		private System.Windows.Forms.Label lblIslamic;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			// Getting today date and converting it to Persian date
			Persia.SunDate sunDate = Persia.Calendar.ConvertToPersian(DateTime.Now);
			// Converting latin year number to persian number
			txtSetYear.Text = Persia.Number.ConvertToPersian(sunDate.ArrayType[0]);
			// Getting the persian month number
			comboMonth.SelectedIndex = sunDate.ArrayType[1]-1;
			// Getting the day of the month number
			comboDays.SelectedIndex  = sunDate.ArrayType[2]-1;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.lblSimple = new System.Windows.Forms.Label();
			this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
			this.btnConvertToPersian = new System.Windows.Forms.Button();
			this.lblPersian = new System.Windows.Forms.Label();
			this.lblWeekday = new System.Windows.Forms.Label();
			this.txtYear = new System.Windows.Forms.TextBox();
			this.txtMonth = new System.Windows.Forms.TextBox();
			this.txtDay = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.lbl2 = new System.Windows.Forms.Label();
			this.lbl3 = new System.Windows.Forms.Label();
			this.lbl1 = new System.Windows.Forms.Label();
			this.comboMonth = new System.Windows.Forms.ComboBox();
			this.txtSetYear = new System.Windows.Forms.TextBox();
			this.comboDays = new System.Windows.Forms.ComboBox();
			this.btnConvertToGregorian = new System.Windows.Forms.Button();
			this.lblGregorian = new System.Windows.Forms.Label();
			this.btnClose = new System.Windows.Forms.Button();
			this.lblLeap = new System.Windows.Forms.Label();
			this.lblYear = new System.Windows.Forms.Label();
			this.btnConvertToIslamic = new System.Windows.Forms.Button();
			this.lblIslamic = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblSimple
			// 
			this.lblSimple.AccessibleDescription = resources.GetString("lblSimple.AccessibleDescription");
			this.lblSimple.AccessibleName = resources.GetString("lblSimple.AccessibleName");
			this.lblSimple.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblSimple.Anchor")));
			this.lblSimple.AutoSize = ((bool)(resources.GetObject("lblSimple.AutoSize")));
			this.lblSimple.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblSimple.Dock")));
			this.lblSimple.Enabled = ((bool)(resources.GetObject("lblSimple.Enabled")));
			this.lblSimple.Font = ((System.Drawing.Font)(resources.GetObject("lblSimple.Font")));
			this.lblSimple.Image = ((System.Drawing.Image)(resources.GetObject("lblSimple.Image")));
			this.lblSimple.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblSimple.ImageAlign")));
			this.lblSimple.ImageIndex = ((int)(resources.GetObject("lblSimple.ImageIndex")));
			this.lblSimple.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblSimple.ImeMode")));
			this.lblSimple.Location = ((System.Drawing.Point)(resources.GetObject("lblSimple.Location")));
			this.lblSimple.Name = "lblSimple";
			this.lblSimple.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblSimple.RightToLeft")));
			this.lblSimple.Size = ((System.Drawing.Size)(resources.GetObject("lblSimple.Size")));
			this.lblSimple.TabIndex = ((int)(resources.GetObject("lblSimple.TabIndex")));
			this.lblSimple.Text = resources.GetString("lblSimple.Text");
			this.lblSimple.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblSimple.TextAlign")));
			this.lblSimple.Visible = ((bool)(resources.GetObject("lblSimple.Visible")));
			// 
			// monthCalendar1
			// 
			this.monthCalendar1.AccessibleDescription = resources.GetString("monthCalendar1.AccessibleDescription");
			this.monthCalendar1.AccessibleName = resources.GetString("monthCalendar1.AccessibleName");
			this.monthCalendar1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("monthCalendar1.Anchor")));
			this.monthCalendar1.AnnuallyBoldedDates = ((System.DateTime[])(resources.GetObject("monthCalendar1.AnnuallyBoldedDates")));
			this.monthCalendar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("monthCalendar1.BackgroundImage")));
			this.monthCalendar1.BoldedDates = ((System.DateTime[])(resources.GetObject("monthCalendar1.BoldedDates")));
			this.monthCalendar1.CalendarDimensions = ((System.Drawing.Size)(resources.GetObject("monthCalendar1.CalendarDimensions")));
			this.monthCalendar1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("monthCalendar1.Dock")));
			this.monthCalendar1.Enabled = ((bool)(resources.GetObject("monthCalendar1.Enabled")));
			this.monthCalendar1.FirstDayOfWeek = ((System.Windows.Forms.Day)(resources.GetObject("monthCalendar1.FirstDayOfWeek")));
			this.monthCalendar1.Font = ((System.Drawing.Font)(resources.GetObject("monthCalendar1.Font")));
			this.monthCalendar1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("monthCalendar1.ImeMode")));
			this.monthCalendar1.Location = ((System.Drawing.Point)(resources.GetObject("monthCalendar1.Location")));
			this.monthCalendar1.MonthlyBoldedDates = ((System.DateTime[])(resources.GetObject("monthCalendar1.MonthlyBoldedDates")));
			this.monthCalendar1.Name = "monthCalendar1";
			this.monthCalendar1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("monthCalendar1.RightToLeft")));
			this.monthCalendar1.ShowWeekNumbers = ((bool)(resources.GetObject("monthCalendar1.ShowWeekNumbers")));
			this.monthCalendar1.Size = ((System.Drawing.Size)(resources.GetObject("monthCalendar1.Size")));
			this.monthCalendar1.TabIndex = ((int)(resources.GetObject("monthCalendar1.TabIndex")));
			this.monthCalendar1.Visible = ((bool)(resources.GetObject("monthCalendar1.Visible")));
			// 
			// btnConvertToPersian
			// 
			this.btnConvertToPersian.AccessibleDescription = resources.GetString("btnConvertToPersian.AccessibleDescription");
			this.btnConvertToPersian.AccessibleName = resources.GetString("btnConvertToPersian.AccessibleName");
			this.btnConvertToPersian.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnConvertToPersian.Anchor")));
			this.btnConvertToPersian.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConvertToPersian.BackgroundImage")));
			this.btnConvertToPersian.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnConvertToPersian.Dock")));
			this.btnConvertToPersian.Enabled = ((bool)(resources.GetObject("btnConvertToPersian.Enabled")));
			this.btnConvertToPersian.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnConvertToPersian.FlatStyle")));
			this.btnConvertToPersian.Font = ((System.Drawing.Font)(resources.GetObject("btnConvertToPersian.Font")));
			this.btnConvertToPersian.Image = ((System.Drawing.Image)(resources.GetObject("btnConvertToPersian.Image")));
			this.btnConvertToPersian.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnConvertToPersian.ImageAlign")));
			this.btnConvertToPersian.ImageIndex = ((int)(resources.GetObject("btnConvertToPersian.ImageIndex")));
			this.btnConvertToPersian.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnConvertToPersian.ImeMode")));
			this.btnConvertToPersian.Location = ((System.Drawing.Point)(resources.GetObject("btnConvertToPersian.Location")));
			this.btnConvertToPersian.Name = "btnConvertToPersian";
			this.btnConvertToPersian.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnConvertToPersian.RightToLeft")));
			this.btnConvertToPersian.Size = ((System.Drawing.Size)(resources.GetObject("btnConvertToPersian.Size")));
			this.btnConvertToPersian.TabIndex = ((int)(resources.GetObject("btnConvertToPersian.TabIndex")));
			this.btnConvertToPersian.Text = resources.GetString("btnConvertToPersian.Text");
			this.btnConvertToPersian.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnConvertToPersian.TextAlign")));
			this.btnConvertToPersian.Visible = ((bool)(resources.GetObject("btnConvertToPersian.Visible")));
			this.btnConvertToPersian.Click += new System.EventHandler(this.btnConvertToPersian_Click);
			// 
			// lblPersian
			// 
			this.lblPersian.AccessibleDescription = resources.GetString("lblPersian.AccessibleDescription");
			this.lblPersian.AccessibleName = resources.GetString("lblPersian.AccessibleName");
			this.lblPersian.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblPersian.Anchor")));
			this.lblPersian.AutoSize = ((bool)(resources.GetObject("lblPersian.AutoSize")));
			this.lblPersian.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblPersian.Dock")));
			this.lblPersian.Enabled = ((bool)(resources.GetObject("lblPersian.Enabled")));
			this.lblPersian.Font = ((System.Drawing.Font)(resources.GetObject("lblPersian.Font")));
			this.lblPersian.Image = ((System.Drawing.Image)(resources.GetObject("lblPersian.Image")));
			this.lblPersian.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblPersian.ImageAlign")));
			this.lblPersian.ImageIndex = ((int)(resources.GetObject("lblPersian.ImageIndex")));
			this.lblPersian.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblPersian.ImeMode")));
			this.lblPersian.Location = ((System.Drawing.Point)(resources.GetObject("lblPersian.Location")));
			this.lblPersian.Name = "lblPersian";
			this.lblPersian.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblPersian.RightToLeft")));
			this.lblPersian.Size = ((System.Drawing.Size)(resources.GetObject("lblPersian.Size")));
			this.lblPersian.TabIndex = ((int)(resources.GetObject("lblPersian.TabIndex")));
			this.lblPersian.Text = resources.GetString("lblPersian.Text");
			this.lblPersian.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblPersian.TextAlign")));
			this.lblPersian.Visible = ((bool)(resources.GetObject("lblPersian.Visible")));
			// 
			// lblWeekday
			// 
			this.lblWeekday.AccessibleDescription = resources.GetString("lblWeekday.AccessibleDescription");
			this.lblWeekday.AccessibleName = resources.GetString("lblWeekday.AccessibleName");
			this.lblWeekday.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblWeekday.Anchor")));
			this.lblWeekday.AutoSize = ((bool)(resources.GetObject("lblWeekday.AutoSize")));
			this.lblWeekday.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblWeekday.Dock")));
			this.lblWeekday.Enabled = ((bool)(resources.GetObject("lblWeekday.Enabled")));
			this.lblWeekday.Font = ((System.Drawing.Font)(resources.GetObject("lblWeekday.Font")));
			this.lblWeekday.Image = ((System.Drawing.Image)(resources.GetObject("lblWeekday.Image")));
			this.lblWeekday.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblWeekday.ImageAlign")));
			this.lblWeekday.ImageIndex = ((int)(resources.GetObject("lblWeekday.ImageIndex")));
			this.lblWeekday.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblWeekday.ImeMode")));
			this.lblWeekday.Location = ((System.Drawing.Point)(resources.GetObject("lblWeekday.Location")));
			this.lblWeekday.Name = "lblWeekday";
			this.lblWeekday.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblWeekday.RightToLeft")));
			this.lblWeekday.Size = ((System.Drawing.Size)(resources.GetObject("lblWeekday.Size")));
			this.lblWeekday.TabIndex = ((int)(resources.GetObject("lblWeekday.TabIndex")));
			this.lblWeekday.Text = resources.GetString("lblWeekday.Text");
			this.lblWeekday.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblWeekday.TextAlign")));
			this.lblWeekday.Visible = ((bool)(resources.GetObject("lblWeekday.Visible")));
			// 
			// txtYear
			// 
			this.txtYear.AccessibleDescription = resources.GetString("txtYear.AccessibleDescription");
			this.txtYear.AccessibleName = resources.GetString("txtYear.AccessibleName");
			this.txtYear.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("txtYear.Anchor")));
			this.txtYear.AutoSize = ((bool)(resources.GetObject("txtYear.AutoSize")));
			this.txtYear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtYear.BackgroundImage")));
			this.txtYear.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("txtYear.Dock")));
			this.txtYear.Enabled = ((bool)(resources.GetObject("txtYear.Enabled")));
			this.txtYear.Font = ((System.Drawing.Font)(resources.GetObject("txtYear.Font")));
			this.txtYear.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("txtYear.ImeMode")));
			this.txtYear.Location = ((System.Drawing.Point)(resources.GetObject("txtYear.Location")));
			this.txtYear.MaxLength = ((int)(resources.GetObject("txtYear.MaxLength")));
			this.txtYear.Multiline = ((bool)(resources.GetObject("txtYear.Multiline")));
			this.txtYear.Name = "txtYear";
			this.txtYear.PasswordChar = ((char)(resources.GetObject("txtYear.PasswordChar")));
			this.txtYear.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("txtYear.RightToLeft")));
			this.txtYear.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("txtYear.ScrollBars")));
			this.txtYear.Size = ((System.Drawing.Size)(resources.GetObject("txtYear.Size")));
			this.txtYear.TabIndex = ((int)(resources.GetObject("txtYear.TabIndex")));
			this.txtYear.Text = resources.GetString("txtYear.Text");
			this.txtYear.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("txtYear.TextAlign")));
			this.txtYear.Visible = ((bool)(resources.GetObject("txtYear.Visible")));
			this.txtYear.WordWrap = ((bool)(resources.GetObject("txtYear.WordWrap")));
			// 
			// txtMonth
			// 
			this.txtMonth.AccessibleDescription = resources.GetString("txtMonth.AccessibleDescription");
			this.txtMonth.AccessibleName = resources.GetString("txtMonth.AccessibleName");
			this.txtMonth.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("txtMonth.Anchor")));
			this.txtMonth.AutoSize = ((bool)(resources.GetObject("txtMonth.AutoSize")));
			this.txtMonth.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtMonth.BackgroundImage")));
			this.txtMonth.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("txtMonth.Dock")));
			this.txtMonth.Enabled = ((bool)(resources.GetObject("txtMonth.Enabled")));
			this.txtMonth.Font = ((System.Drawing.Font)(resources.GetObject("txtMonth.Font")));
			this.txtMonth.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("txtMonth.ImeMode")));
			this.txtMonth.Location = ((System.Drawing.Point)(resources.GetObject("txtMonth.Location")));
			this.txtMonth.MaxLength = ((int)(resources.GetObject("txtMonth.MaxLength")));
			this.txtMonth.Multiline = ((bool)(resources.GetObject("txtMonth.Multiline")));
			this.txtMonth.Name = "txtMonth";
			this.txtMonth.PasswordChar = ((char)(resources.GetObject("txtMonth.PasswordChar")));
			this.txtMonth.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("txtMonth.RightToLeft")));
			this.txtMonth.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("txtMonth.ScrollBars")));
			this.txtMonth.Size = ((System.Drawing.Size)(resources.GetObject("txtMonth.Size")));
			this.txtMonth.TabIndex = ((int)(resources.GetObject("txtMonth.TabIndex")));
			this.txtMonth.Text = resources.GetString("txtMonth.Text");
			this.txtMonth.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("txtMonth.TextAlign")));
			this.txtMonth.Visible = ((bool)(resources.GetObject("txtMonth.Visible")));
			this.txtMonth.WordWrap = ((bool)(resources.GetObject("txtMonth.WordWrap")));
			// 
			// txtDay
			// 
			this.txtDay.AccessibleDescription = resources.GetString("txtDay.AccessibleDescription");
			this.txtDay.AccessibleName = resources.GetString("txtDay.AccessibleName");
			this.txtDay.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("txtDay.Anchor")));
			this.txtDay.AutoSize = ((bool)(resources.GetObject("txtDay.AutoSize")));
			this.txtDay.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtDay.BackgroundImage")));
			this.txtDay.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("txtDay.Dock")));
			this.txtDay.Enabled = ((bool)(resources.GetObject("txtDay.Enabled")));
			this.txtDay.Font = ((System.Drawing.Font)(resources.GetObject("txtDay.Font")));
			this.txtDay.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("txtDay.ImeMode")));
			this.txtDay.Location = ((System.Drawing.Point)(resources.GetObject("txtDay.Location")));
			this.txtDay.MaxLength = ((int)(resources.GetObject("txtDay.MaxLength")));
			this.txtDay.Multiline = ((bool)(resources.GetObject("txtDay.Multiline")));
			this.txtDay.Name = "txtDay";
			this.txtDay.PasswordChar = ((char)(resources.GetObject("txtDay.PasswordChar")));
			this.txtDay.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("txtDay.RightToLeft")));
			this.txtDay.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("txtDay.ScrollBars")));
			this.txtDay.Size = ((System.Drawing.Size)(resources.GetObject("txtDay.Size")));
			this.txtDay.TabIndex = ((int)(resources.GetObject("txtDay.TabIndex")));
			this.txtDay.Text = resources.GetString("txtDay.Text");
			this.txtDay.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("txtDay.TextAlign")));
			this.txtDay.Visible = ((bool)(resources.GetObject("txtDay.Visible")));
			this.txtDay.WordWrap = ((bool)(resources.GetObject("txtDay.WordWrap")));
			// 
			// label4
			// 
			this.label4.AccessibleDescription = resources.GetString("label4.AccessibleDescription");
			this.label4.AccessibleName = resources.GetString("label4.AccessibleName");
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label4.Anchor")));
			this.label4.AutoSize = ((bool)(resources.GetObject("label4.AutoSize")));
			this.label4.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label4.Dock")));
			this.label4.Enabled = ((bool)(resources.GetObject("label4.Enabled")));
			this.label4.Font = ((System.Drawing.Font)(resources.GetObject("label4.Font")));
			this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
			this.label4.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label4.ImageAlign")));
			this.label4.ImageIndex = ((int)(resources.GetObject("label4.ImageIndex")));
			this.label4.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label4.ImeMode")));
			this.label4.Location = ((System.Drawing.Point)(resources.GetObject("label4.Location")));
			this.label4.Name = "label4";
			this.label4.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label4.RightToLeft")));
			this.label4.Size = ((System.Drawing.Size)(resources.GetObject("label4.Size")));
			this.label4.TabIndex = ((int)(resources.GetObject("label4.TabIndex")));
			this.label4.Text = resources.GetString("label4.Text");
			this.label4.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label4.TextAlign")));
			this.label4.Visible = ((bool)(resources.GetObject("label4.Visible")));
			// 
			// label5
			// 
			this.label5.AccessibleDescription = resources.GetString("label5.AccessibleDescription");
			this.label5.AccessibleName = resources.GetString("label5.AccessibleName");
			this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label5.Anchor")));
			this.label5.AutoSize = ((bool)(resources.GetObject("label5.AutoSize")));
			this.label5.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label5.Dock")));
			this.label5.Enabled = ((bool)(resources.GetObject("label5.Enabled")));
			this.label5.Font = ((System.Drawing.Font)(resources.GetObject("label5.Font")));
			this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
			this.label5.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label5.ImageAlign")));
			this.label5.ImageIndex = ((int)(resources.GetObject("label5.ImageIndex")));
			this.label5.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label5.ImeMode")));
			this.label5.Location = ((System.Drawing.Point)(resources.GetObject("label5.Location")));
			this.label5.Name = "label5";
			this.label5.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label5.RightToLeft")));
			this.label5.Size = ((System.Drawing.Size)(resources.GetObject("label5.Size")));
			this.label5.TabIndex = ((int)(resources.GetObject("label5.TabIndex")));
			this.label5.Text = resources.GetString("label5.Text");
			this.label5.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label5.TextAlign")));
			this.label5.Visible = ((bool)(resources.GetObject("label5.Visible")));
			// 
			// label6
			// 
			this.label6.AccessibleDescription = resources.GetString("label6.AccessibleDescription");
			this.label6.AccessibleName = resources.GetString("label6.AccessibleName");
			this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("label6.Anchor")));
			this.label6.AutoSize = ((bool)(resources.GetObject("label6.AutoSize")));
			this.label6.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("label6.Dock")));
			this.label6.Enabled = ((bool)(resources.GetObject("label6.Enabled")));
			this.label6.Font = ((System.Drawing.Font)(resources.GetObject("label6.Font")));
			this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
			this.label6.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label6.ImageAlign")));
			this.label6.ImageIndex = ((int)(resources.GetObject("label6.ImageIndex")));
			this.label6.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("label6.ImeMode")));
			this.label6.Location = ((System.Drawing.Point)(resources.GetObject("label6.Location")));
			this.label6.Name = "label6";
			this.label6.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("label6.RightToLeft")));
			this.label6.Size = ((System.Drawing.Size)(resources.GetObject("label6.Size")));
			this.label6.TabIndex = ((int)(resources.GetObject("label6.TabIndex")));
			this.label6.Text = resources.GetString("label6.Text");
			this.label6.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("label6.TextAlign")));
			this.label6.Visible = ((bool)(resources.GetObject("label6.Visible")));
			// 
			// lbl2
			// 
			this.lbl2.AccessibleDescription = resources.GetString("lbl2.AccessibleDescription");
			this.lbl2.AccessibleName = resources.GetString("lbl2.AccessibleName");
			this.lbl2.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lbl2.Anchor")));
			this.lbl2.AutoSize = ((bool)(resources.GetObject("lbl2.AutoSize")));
			this.lbl2.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lbl2.Dock")));
			this.lbl2.Enabled = ((bool)(resources.GetObject("lbl2.Enabled")));
			this.lbl2.Font = ((System.Drawing.Font)(resources.GetObject("lbl2.Font")));
			this.lbl2.Image = ((System.Drawing.Image)(resources.GetObject("lbl2.Image")));
			this.lbl2.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbl2.ImageAlign")));
			this.lbl2.ImageIndex = ((int)(resources.GetObject("lbl2.ImageIndex")));
			this.lbl2.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lbl2.ImeMode")));
			this.lbl2.Location = ((System.Drawing.Point)(resources.GetObject("lbl2.Location")));
			this.lbl2.Name = "lbl2";
			this.lbl2.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lbl2.RightToLeft")));
			this.lbl2.Size = ((System.Drawing.Size)(resources.GetObject("lbl2.Size")));
			this.lbl2.TabIndex = ((int)(resources.GetObject("lbl2.TabIndex")));
			this.lbl2.Text = resources.GetString("lbl2.Text");
			this.lbl2.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbl2.TextAlign")));
			this.lbl2.Visible = ((bool)(resources.GetObject("lbl2.Visible")));
			// 
			// lbl3
			// 
			this.lbl3.AccessibleDescription = resources.GetString("lbl3.AccessibleDescription");
			this.lbl3.AccessibleName = resources.GetString("lbl3.AccessibleName");
			this.lbl3.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lbl3.Anchor")));
			this.lbl3.AutoSize = ((bool)(resources.GetObject("lbl3.AutoSize")));
			this.lbl3.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lbl3.Dock")));
			this.lbl3.Enabled = ((bool)(resources.GetObject("lbl3.Enabled")));
			this.lbl3.Font = ((System.Drawing.Font)(resources.GetObject("lbl3.Font")));
			this.lbl3.Image = ((System.Drawing.Image)(resources.GetObject("lbl3.Image")));
			this.lbl3.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbl3.ImageAlign")));
			this.lbl3.ImageIndex = ((int)(resources.GetObject("lbl3.ImageIndex")));
			this.lbl3.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lbl3.ImeMode")));
			this.lbl3.Location = ((System.Drawing.Point)(resources.GetObject("lbl3.Location")));
			this.lbl3.Name = "lbl3";
			this.lbl3.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lbl3.RightToLeft")));
			this.lbl3.Size = ((System.Drawing.Size)(resources.GetObject("lbl3.Size")));
			this.lbl3.TabIndex = ((int)(resources.GetObject("lbl3.TabIndex")));
			this.lbl3.Text = resources.GetString("lbl3.Text");
			this.lbl3.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbl3.TextAlign")));
			this.lbl3.Visible = ((bool)(resources.GetObject("lbl3.Visible")));
			// 
			// lbl1
			// 
			this.lbl1.AccessibleDescription = resources.GetString("lbl1.AccessibleDescription");
			this.lbl1.AccessibleName = resources.GetString("lbl1.AccessibleName");
			this.lbl1.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lbl1.Anchor")));
			this.lbl1.AutoSize = ((bool)(resources.GetObject("lbl1.AutoSize")));
			this.lbl1.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lbl1.Dock")));
			this.lbl1.Enabled = ((bool)(resources.GetObject("lbl1.Enabled")));
			this.lbl1.Font = ((System.Drawing.Font)(resources.GetObject("lbl1.Font")));
			this.lbl1.Image = ((System.Drawing.Image)(resources.GetObject("lbl1.Image")));
			this.lbl1.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbl1.ImageAlign")));
			this.lbl1.ImageIndex = ((int)(resources.GetObject("lbl1.ImageIndex")));
			this.lbl1.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lbl1.ImeMode")));
			this.lbl1.Location = ((System.Drawing.Point)(resources.GetObject("lbl1.Location")));
			this.lbl1.Name = "lbl1";
			this.lbl1.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lbl1.RightToLeft")));
			this.lbl1.Size = ((System.Drawing.Size)(resources.GetObject("lbl1.Size")));
			this.lbl1.TabIndex = ((int)(resources.GetObject("lbl1.TabIndex")));
			this.lbl1.Text = resources.GetString("lbl1.Text");
			this.lbl1.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lbl1.TextAlign")));
			this.lbl1.Visible = ((bool)(resources.GetObject("lbl1.Visible")));
			// 
			// comboMonth
			// 
			this.comboMonth.AccessibleDescription = resources.GetString("comboMonth.AccessibleDescription");
			this.comboMonth.AccessibleName = resources.GetString("comboMonth.AccessibleName");
			this.comboMonth.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("comboMonth.Anchor")));
			this.comboMonth.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("comboMonth.BackgroundImage")));
			this.comboMonth.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("comboMonth.Dock")));
			this.comboMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboMonth.DropDownWidth = 80;
			this.comboMonth.Enabled = ((bool)(resources.GetObject("comboMonth.Enabled")));
			this.comboMonth.Font = ((System.Drawing.Font)(resources.GetObject("comboMonth.Font")));
			this.comboMonth.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("comboMonth.ImeMode")));
			this.comboMonth.IntegralHeight = ((bool)(resources.GetObject("comboMonth.IntegralHeight")));
			this.comboMonth.ItemHeight = ((int)(resources.GetObject("comboMonth.ItemHeight")));
			this.comboMonth.Items.AddRange(new object[] {
															resources.GetString("comboMonth.Items"),
															resources.GetString("comboMonth.Items1"),
															resources.GetString("comboMonth.Items2"),
															resources.GetString("comboMonth.Items3"),
															resources.GetString("comboMonth.Items4"),
															resources.GetString("comboMonth.Items5"),
															resources.GetString("comboMonth.Items6"),
															resources.GetString("comboMonth.Items7"),
															resources.GetString("comboMonth.Items8"),
															resources.GetString("comboMonth.Items9"),
															resources.GetString("comboMonth.Items10"),
															resources.GetString("comboMonth.Items11")});
			this.comboMonth.Location = ((System.Drawing.Point)(resources.GetObject("comboMonth.Location")));
			this.comboMonth.MaxDropDownItems = ((int)(resources.GetObject("comboMonth.MaxDropDownItems")));
			this.comboMonth.MaxLength = ((int)(resources.GetObject("comboMonth.MaxLength")));
			this.comboMonth.Name = "comboMonth";
			this.comboMonth.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("comboMonth.RightToLeft")));
			this.comboMonth.Size = ((System.Drawing.Size)(resources.GetObject("comboMonth.Size")));
			this.comboMonth.TabIndex = ((int)(resources.GetObject("comboMonth.TabIndex")));
			this.comboMonth.Text = resources.GetString("comboMonth.Text");
			this.comboMonth.Visible = ((bool)(resources.GetObject("comboMonth.Visible")));
			// 
			// txtSetYear
			// 
			this.txtSetYear.AccessibleDescription = resources.GetString("txtSetYear.AccessibleDescription");
			this.txtSetYear.AccessibleName = resources.GetString("txtSetYear.AccessibleName");
			this.txtSetYear.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("txtSetYear.Anchor")));
			this.txtSetYear.AutoSize = ((bool)(resources.GetObject("txtSetYear.AutoSize")));
			this.txtSetYear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSetYear.BackgroundImage")));
			this.txtSetYear.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("txtSetYear.Dock")));
			this.txtSetYear.Enabled = ((bool)(resources.GetObject("txtSetYear.Enabled")));
			this.txtSetYear.Font = ((System.Drawing.Font)(resources.GetObject("txtSetYear.Font")));
			this.txtSetYear.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("txtSetYear.ImeMode")));
			this.txtSetYear.Location = ((System.Drawing.Point)(resources.GetObject("txtSetYear.Location")));
			this.txtSetYear.MaxLength = ((int)(resources.GetObject("txtSetYear.MaxLength")));
			this.txtSetYear.Multiline = ((bool)(resources.GetObject("txtSetYear.Multiline")));
			this.txtSetYear.Name = "txtSetYear";
			this.txtSetYear.PasswordChar = ((char)(resources.GetObject("txtSetYear.PasswordChar")));
			this.txtSetYear.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("txtSetYear.RightToLeft")));
			this.txtSetYear.ScrollBars = ((System.Windows.Forms.ScrollBars)(resources.GetObject("txtSetYear.ScrollBars")));
			this.txtSetYear.Size = ((System.Drawing.Size)(resources.GetObject("txtSetYear.Size")));
			this.txtSetYear.TabIndex = ((int)(resources.GetObject("txtSetYear.TabIndex")));
			this.txtSetYear.Text = resources.GetString("txtSetYear.Text");
			this.txtSetYear.TextAlign = ((System.Windows.Forms.HorizontalAlignment)(resources.GetObject("txtSetYear.TextAlign")));
			this.txtSetYear.Visible = ((bool)(resources.GetObject("txtSetYear.Visible")));
			this.txtSetYear.WordWrap = ((bool)(resources.GetObject("txtSetYear.WordWrap")));
			// 
			// comboDays
			// 
			this.comboDays.AccessibleDescription = resources.GetString("comboDays.AccessibleDescription");
			this.comboDays.AccessibleName = resources.GetString("comboDays.AccessibleName");
			this.comboDays.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("comboDays.Anchor")));
			this.comboDays.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("comboDays.BackgroundImage")));
			this.comboDays.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("comboDays.Dock")));
			this.comboDays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboDays.DropDownWidth = 40;
			this.comboDays.Enabled = ((bool)(resources.GetObject("comboDays.Enabled")));
			this.comboDays.Font = ((System.Drawing.Font)(resources.GetObject("comboDays.Font")));
			this.comboDays.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("comboDays.ImeMode")));
			this.comboDays.IntegralHeight = ((bool)(resources.GetObject("comboDays.IntegralHeight")));
			this.comboDays.ItemHeight = ((int)(resources.GetObject("comboDays.ItemHeight")));
			this.comboDays.Items.AddRange(new object[] {
														   resources.GetString("comboDays.Items"),
														   resources.GetString("comboDays.Items1"),
														   resources.GetString("comboDays.Items2"),
														   resources.GetString("comboDays.Items3"),
														   resources.GetString("comboDays.Items4"),
														   resources.GetString("comboDays.Items5"),
														   resources.GetString("comboDays.Items6"),
														   resources.GetString("comboDays.Items7"),
														   resources.GetString("comboDays.Items8"),
														   resources.GetString("comboDays.Items9"),
														   resources.GetString("comboDays.Items10"),
														   resources.GetString("comboDays.Items11"),
														   resources.GetString("comboDays.Items12"),
														   resources.GetString("comboDays.Items13"),
														   resources.GetString("comboDays.Items14"),
														   resources.GetString("comboDays.Items15"),
														   resources.GetString("comboDays.Items16"),
														   resources.GetString("comboDays.Items17"),
														   resources.GetString("comboDays.Items18"),
														   resources.GetString("comboDays.Items19"),
														   resources.GetString("comboDays.Items20"),
														   resources.GetString("comboDays.Items21"),
														   resources.GetString("comboDays.Items22"),
														   resources.GetString("comboDays.Items23"),
														   resources.GetString("comboDays.Items24"),
														   resources.GetString("comboDays.Items25"),
														   resources.GetString("comboDays.Items26"),
														   resources.GetString("comboDays.Items27"),
														   resources.GetString("comboDays.Items28"),
														   resources.GetString("comboDays.Items29"),
														   resources.GetString("comboDays.Items30")});
			this.comboDays.Location = ((System.Drawing.Point)(resources.GetObject("comboDays.Location")));
			this.comboDays.MaxDropDownItems = ((int)(resources.GetObject("comboDays.MaxDropDownItems")));
			this.comboDays.MaxLength = ((int)(resources.GetObject("comboDays.MaxLength")));
			this.comboDays.Name = "comboDays";
			this.comboDays.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("comboDays.RightToLeft")));
			this.comboDays.Size = ((System.Drawing.Size)(resources.GetObject("comboDays.Size")));
			this.comboDays.TabIndex = ((int)(resources.GetObject("comboDays.TabIndex")));
			this.comboDays.Text = resources.GetString("comboDays.Text");
			this.comboDays.Visible = ((bool)(resources.GetObject("comboDays.Visible")));
			// 
			// btnConvertToGregorian
			// 
			this.btnConvertToGregorian.AccessibleDescription = resources.GetString("btnConvertToGregorian.AccessibleDescription");
			this.btnConvertToGregorian.AccessibleName = resources.GetString("btnConvertToGregorian.AccessibleName");
			this.btnConvertToGregorian.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnConvertToGregorian.Anchor")));
			this.btnConvertToGregorian.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConvertToGregorian.BackgroundImage")));
			this.btnConvertToGregorian.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnConvertToGregorian.Dock")));
			this.btnConvertToGregorian.Enabled = ((bool)(resources.GetObject("btnConvertToGregorian.Enabled")));
			this.btnConvertToGregorian.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnConvertToGregorian.FlatStyle")));
			this.btnConvertToGregorian.Font = ((System.Drawing.Font)(resources.GetObject("btnConvertToGregorian.Font")));
			this.btnConvertToGregorian.Image = ((System.Drawing.Image)(resources.GetObject("btnConvertToGregorian.Image")));
			this.btnConvertToGregorian.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnConvertToGregorian.ImageAlign")));
			this.btnConvertToGregorian.ImageIndex = ((int)(resources.GetObject("btnConvertToGregorian.ImageIndex")));
			this.btnConvertToGregorian.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnConvertToGregorian.ImeMode")));
			this.btnConvertToGregorian.Location = ((System.Drawing.Point)(resources.GetObject("btnConvertToGregorian.Location")));
			this.btnConvertToGregorian.Name = "btnConvertToGregorian";
			this.btnConvertToGregorian.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnConvertToGregorian.RightToLeft")));
			this.btnConvertToGregorian.Size = ((System.Drawing.Size)(resources.GetObject("btnConvertToGregorian.Size")));
			this.btnConvertToGregorian.TabIndex = ((int)(resources.GetObject("btnConvertToGregorian.TabIndex")));
			this.btnConvertToGregorian.Text = resources.GetString("btnConvertToGregorian.Text");
			this.btnConvertToGregorian.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnConvertToGregorian.TextAlign")));
			this.btnConvertToGregorian.Visible = ((bool)(resources.GetObject("btnConvertToGregorian.Visible")));
			this.btnConvertToGregorian.Click += new System.EventHandler(this.btnConvertToGregorian_Click);
			// 
			// lblGregorian
			// 
			this.lblGregorian.AccessibleDescription = resources.GetString("lblGregorian.AccessibleDescription");
			this.lblGregorian.AccessibleName = resources.GetString("lblGregorian.AccessibleName");
			this.lblGregorian.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblGregorian.Anchor")));
			this.lblGregorian.AutoSize = ((bool)(resources.GetObject("lblGregorian.AutoSize")));
			this.lblGregorian.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblGregorian.Dock")));
			this.lblGregorian.Enabled = ((bool)(resources.GetObject("lblGregorian.Enabled")));
			this.lblGregorian.Font = ((System.Drawing.Font)(resources.GetObject("lblGregorian.Font")));
			this.lblGregorian.Image = ((System.Drawing.Image)(resources.GetObject("lblGregorian.Image")));
			this.lblGregorian.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblGregorian.ImageAlign")));
			this.lblGregorian.ImageIndex = ((int)(resources.GetObject("lblGregorian.ImageIndex")));
			this.lblGregorian.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblGregorian.ImeMode")));
			this.lblGregorian.Location = ((System.Drawing.Point)(resources.GetObject("lblGregorian.Location")));
			this.lblGregorian.Name = "lblGregorian";
			this.lblGregorian.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblGregorian.RightToLeft")));
			this.lblGregorian.Size = ((System.Drawing.Size)(resources.GetObject("lblGregorian.Size")));
			this.lblGregorian.TabIndex = ((int)(resources.GetObject("lblGregorian.TabIndex")));
			this.lblGregorian.Text = resources.GetString("lblGregorian.Text");
			this.lblGregorian.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblGregorian.TextAlign")));
			this.lblGregorian.Visible = ((bool)(resources.GetObject("lblGregorian.Visible")));
			// 
			// btnClose
			// 
			this.btnClose.AccessibleDescription = resources.GetString("btnClose.AccessibleDescription");
			this.btnClose.AccessibleName = resources.GetString("btnClose.AccessibleName");
			this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnClose.Anchor")));
			this.btnClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClose.BackgroundImage")));
			this.btnClose.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnClose.Dock")));
			this.btnClose.Enabled = ((bool)(resources.GetObject("btnClose.Enabled")));
			this.btnClose.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnClose.FlatStyle")));
			this.btnClose.Font = ((System.Drawing.Font)(resources.GetObject("btnClose.Font")));
			this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
			this.btnClose.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnClose.ImageAlign")));
			this.btnClose.ImageIndex = ((int)(resources.GetObject("btnClose.ImageIndex")));
			this.btnClose.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnClose.ImeMode")));
			this.btnClose.Location = ((System.Drawing.Point)(resources.GetObject("btnClose.Location")));
			this.btnClose.Name = "btnClose";
			this.btnClose.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnClose.RightToLeft")));
			this.btnClose.Size = ((System.Drawing.Size)(resources.GetObject("btnClose.Size")));
			this.btnClose.TabIndex = ((int)(resources.GetObject("btnClose.TabIndex")));
			this.btnClose.Text = resources.GetString("btnClose.Text");
			this.btnClose.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnClose.TextAlign")));
			this.btnClose.Visible = ((bool)(resources.GetObject("btnClose.Visible")));
			this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
			// 
			// lblLeap
			// 
			this.lblLeap.AccessibleDescription = resources.GetString("lblLeap.AccessibleDescription");
			this.lblLeap.AccessibleName = resources.GetString("lblLeap.AccessibleName");
			this.lblLeap.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblLeap.Anchor")));
			this.lblLeap.AutoSize = ((bool)(resources.GetObject("lblLeap.AutoSize")));
			this.lblLeap.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblLeap.Dock")));
			this.lblLeap.Enabled = ((bool)(resources.GetObject("lblLeap.Enabled")));
			this.lblLeap.Font = ((System.Drawing.Font)(resources.GetObject("lblLeap.Font")));
			this.lblLeap.Image = ((System.Drawing.Image)(resources.GetObject("lblLeap.Image")));
			this.lblLeap.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblLeap.ImageAlign")));
			this.lblLeap.ImageIndex = ((int)(resources.GetObject("lblLeap.ImageIndex")));
			this.lblLeap.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblLeap.ImeMode")));
			this.lblLeap.Location = ((System.Drawing.Point)(resources.GetObject("lblLeap.Location")));
			this.lblLeap.Name = "lblLeap";
			this.lblLeap.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblLeap.RightToLeft")));
			this.lblLeap.Size = ((System.Drawing.Size)(resources.GetObject("lblLeap.Size")));
			this.lblLeap.TabIndex = ((int)(resources.GetObject("lblLeap.TabIndex")));
			this.lblLeap.Text = resources.GetString("lblLeap.Text");
			this.lblLeap.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblLeap.TextAlign")));
			this.lblLeap.Visible = ((bool)(resources.GetObject("lblLeap.Visible")));
			// 
			// lblYear
			// 
			this.lblYear.AccessibleDescription = resources.GetString("lblYear.AccessibleDescription");
			this.lblYear.AccessibleName = resources.GetString("lblYear.AccessibleName");
			this.lblYear.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblYear.Anchor")));
			this.lblYear.AutoSize = ((bool)(resources.GetObject("lblYear.AutoSize")));
			this.lblYear.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblYear.Dock")));
			this.lblYear.Enabled = ((bool)(resources.GetObject("lblYear.Enabled")));
			this.lblYear.Font = ((System.Drawing.Font)(resources.GetObject("lblYear.Font")));
			this.lblYear.Image = ((System.Drawing.Image)(resources.GetObject("lblYear.Image")));
			this.lblYear.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblYear.ImageAlign")));
			this.lblYear.ImageIndex = ((int)(resources.GetObject("lblYear.ImageIndex")));
			this.lblYear.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblYear.ImeMode")));
			this.lblYear.Location = ((System.Drawing.Point)(resources.GetObject("lblYear.Location")));
			this.lblYear.Name = "lblYear";
			this.lblYear.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblYear.RightToLeft")));
			this.lblYear.Size = ((System.Drawing.Size)(resources.GetObject("lblYear.Size")));
			this.lblYear.TabIndex = ((int)(resources.GetObject("lblYear.TabIndex")));
			this.lblYear.Text = resources.GetString("lblYear.Text");
			this.lblYear.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblYear.TextAlign")));
			this.lblYear.Visible = ((bool)(resources.GetObject("lblYear.Visible")));
			// 
			// btnConvertToIslamic
			// 
			this.btnConvertToIslamic.AccessibleDescription = resources.GetString("btnConvertToIslamic.AccessibleDescription");
			this.btnConvertToIslamic.AccessibleName = resources.GetString("btnConvertToIslamic.AccessibleName");
			this.btnConvertToIslamic.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("btnConvertToIslamic.Anchor")));
			this.btnConvertToIslamic.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConvertToIslamic.BackgroundImage")));
			this.btnConvertToIslamic.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("btnConvertToIslamic.Dock")));
			this.btnConvertToIslamic.Enabled = ((bool)(resources.GetObject("btnConvertToIslamic.Enabled")));
			this.btnConvertToIslamic.FlatStyle = ((System.Windows.Forms.FlatStyle)(resources.GetObject("btnConvertToIslamic.FlatStyle")));
			this.btnConvertToIslamic.Font = ((System.Drawing.Font)(resources.GetObject("btnConvertToIslamic.Font")));
			this.btnConvertToIslamic.Image = ((System.Drawing.Image)(resources.GetObject("btnConvertToIslamic.Image")));
			this.btnConvertToIslamic.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnConvertToIslamic.ImageAlign")));
			this.btnConvertToIslamic.ImageIndex = ((int)(resources.GetObject("btnConvertToIslamic.ImageIndex")));
			this.btnConvertToIslamic.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("btnConvertToIslamic.ImeMode")));
			this.btnConvertToIslamic.Location = ((System.Drawing.Point)(resources.GetObject("btnConvertToIslamic.Location")));
			this.btnConvertToIslamic.Name = "btnConvertToIslamic";
			this.btnConvertToIslamic.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("btnConvertToIslamic.RightToLeft")));
			this.btnConvertToIslamic.Size = ((System.Drawing.Size)(resources.GetObject("btnConvertToIslamic.Size")));
			this.btnConvertToIslamic.TabIndex = ((int)(resources.GetObject("btnConvertToIslamic.TabIndex")));
			this.btnConvertToIslamic.Text = resources.GetString("btnConvertToIslamic.Text");
			this.btnConvertToIslamic.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("btnConvertToIslamic.TextAlign")));
			this.btnConvertToIslamic.Visible = ((bool)(resources.GetObject("btnConvertToIslamic.Visible")));
			this.btnConvertToIslamic.Click += new System.EventHandler(this.btnConvertToIslamic_Click);
			// 
			// lblIslamic
			// 
			this.lblIslamic.AccessibleDescription = resources.GetString("lblIslamic.AccessibleDescription");
			this.lblIslamic.AccessibleName = resources.GetString("lblIslamic.AccessibleName");
			this.lblIslamic.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("lblIslamic.Anchor")));
			this.lblIslamic.AutoSize = ((bool)(resources.GetObject("lblIslamic.AutoSize")));
			this.lblIslamic.Dock = ((System.Windows.Forms.DockStyle)(resources.GetObject("lblIslamic.Dock")));
			this.lblIslamic.Enabled = ((bool)(resources.GetObject("lblIslamic.Enabled")));
			this.lblIslamic.Font = ((System.Drawing.Font)(resources.GetObject("lblIslamic.Font")));
			this.lblIslamic.Image = ((System.Drawing.Image)(resources.GetObject("lblIslamic.Image")));
			this.lblIslamic.ImageAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblIslamic.ImageAlign")));
			this.lblIslamic.ImageIndex = ((int)(resources.GetObject("lblIslamic.ImageIndex")));
			this.lblIslamic.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("lblIslamic.ImeMode")));
			this.lblIslamic.Location = ((System.Drawing.Point)(resources.GetObject("lblIslamic.Location")));
			this.lblIslamic.Name = "lblIslamic";
			this.lblIslamic.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("lblIslamic.RightToLeft")));
			this.lblIslamic.Size = ((System.Drawing.Size)(resources.GetObject("lblIslamic.Size")));
			this.lblIslamic.TabIndex = ((int)(resources.GetObject("lblIslamic.TabIndex")));
			this.lblIslamic.Text = resources.GetString("lblIslamic.Text");
			this.lblIslamic.TextAlign = ((System.Drawing.ContentAlignment)(resources.GetObject("lblIslamic.TextAlign")));
			this.lblIslamic.Visible = ((bool)(resources.GetObject("lblIslamic.Visible")));
			// 
			// Form1
			// 
			this.AccessibleDescription = resources.GetString("$this.AccessibleDescription");
			this.AccessibleName = resources.GetString("$this.AccessibleName");
			this.AutoScaleBaseSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScaleBaseSize")));
			this.AutoScroll = ((bool)(resources.GetObject("$this.AutoScroll")));
			this.AutoScrollMargin = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMargin")));
			this.AutoScrollMinSize = ((System.Drawing.Size)(resources.GetObject("$this.AutoScrollMinSize")));
			this.BackColor = System.Drawing.Color.Gainsboro;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = ((System.Drawing.Size)(resources.GetObject("$this.ClientSize")));
			this.Controls.Add(this.lblIslamic);
			this.Controls.Add(this.btnConvertToIslamic);
			this.Controls.Add(this.lblYear);
			this.Controls.Add(this.lblLeap);
			this.Controls.Add(this.btnClose);
			this.Controls.Add(this.lblGregorian);
			this.Controls.Add(this.btnConvertToGregorian);
			this.Controls.Add(this.comboDays);
			this.Controls.Add(this.txtSetYear);
			this.Controls.Add(this.comboMonth);
			this.Controls.Add(this.lbl2);
			this.Controls.Add(this.lbl3);
			this.Controls.Add(this.lbl1);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtDay);
			this.Controls.Add(this.txtMonth);
			this.Controls.Add(this.txtYear);
			this.Controls.Add(this.lblWeekday);
			this.Controls.Add(this.lblPersian);
			this.Controls.Add(this.btnConvertToPersian);
			this.Controls.Add(this.monthCalendar1);
			this.Controls.Add(this.lblSimple);
			this.Enabled = ((bool)(resources.GetObject("$this.Enabled")));
			this.Font = ((System.Drawing.Font)(resources.GetObject("$this.Font")));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("$this.ImeMode")));
			this.Location = ((System.Drawing.Point)(resources.GetObject("$this.Location")));
			this.MaximumSize = ((System.Drawing.Size)(resources.GetObject("$this.MaximumSize")));
			this.MinimumSize = ((System.Drawing.Size)(resources.GetObject("$this.MinimumSize")));
			this.Name = "Form1";
			this.RightToLeft = ((System.Windows.Forms.RightToLeft)(resources.GetObject("$this.RightToLeft")));
			this.StartPosition = ((System.Windows.Forms.FormStartPosition)(resources.GetObject("$this.StartPosition")));
			this.Text = resources.GetString("$this.Text");
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnConvertToPersian_Click(object sender, System.EventArgs e)
		{
			/// <summary>
			/// Getting the selected date from month calendar control 
			/// and converting it to Persian date using ConvertToPersian method. 
			/// This method returns an object of SunDate class
			/// </summary>
			Persia.SunDate sunDate = Persia.Calendar.ConvertToPersian(monthCalendar1.SelectionStart);
			// getting the simple format of persian date
			lblSimple.Text  = sunDate.Simple;
			// getting the simple word format of persian date
			lblPersian.Text = sunDate.Persian;
			// getting simple format with day of persian date
			lblWeekday.Text = sunDate.Weekday;

			// Determine if this year is leap (Kabiseh) or not
			if (sunDate.IsLeapYear)
				lblLeap.Text = "�����";
			else
				lblLeap.Text = "����";
			lblYear.Visible = true;

			/* Getting the year, month and day number of persian date.
			   These numbers are in latin format so we can convert
			   them to persian numbers for displaying on TextBoxes */
			txtDay.Text   = Persia.Number.ConvertToPersian(sunDate.ArrayType[2]);
			txtMonth.Text = Persia.Number.ConvertToPersian(sunDate.ArrayType[1]);
			txtYear.Text  = Persia.Number.ConvertToPersian(sunDate.ArrayType[0]);
		}

		private void btnConvertToGregorian_Click(object sender, System.EventArgs e)
		{
			/// <summary>
			/// ConvertToGregorian method converts the Persian or Islamic date
			/// to Gregorian date. Its return value is a DateTime class object.
			/// 
			/// Here we set the year, month and day numbers of Persian date as 
			/// parameters of this method. 
			/// 
			/// We can also set a SunDate class object as a parameter to convert
			/// a Persian date to Gregorian. If we want to convert an Islamic date
			/// to Gregorian we have to give an objebt of MoonDate class as a parameter
			/// </summary>

			// if the text value of txtSetYear is in Persian format we cannot
			// parse it to int. to avoid this problem we must convert it to a Latin format number.
			int year  = int.Parse(Persia.Number.ConvertToLatin(txtSetYear.Text));
			int month = comboMonth.SelectedIndex + 1;
			int day   = comboDays.SelectedIndex + 1;
			lblGregorian.Text = Persia.Calendar.ConvertToGregorian(year, month, day, Persia.DateType.Persian).ToString();
		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void btnConvertToIslamic_Click(object sender, System.EventArgs e)
		{
			int year = int.Parse(Persia.Number.ConvertToLatin(txtSetYear.Text));
			int month = comboMonth.SelectedIndex + 1;
			int day = comboDays.SelectedIndex + 1;
			lblIslamic.Text = Persia.Calendar.ConvertToIslamic(year, month, day, Persia.DateType.Persian).Formal;
		}
	}
}
