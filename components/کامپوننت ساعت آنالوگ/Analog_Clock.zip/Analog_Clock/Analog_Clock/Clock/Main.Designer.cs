﻿namespace Clock
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.analogueClock1 = new GHNet.Windows.Forms.AnalogueClock();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.analogueClock6 = new GHNet.Windows.Forms.AnalogueClock();
            this.analogueClock5 = new GHNet.Windows.Forms.AnalogueClock();
            this.analogueClock4 = new GHNet.Windows.Forms.AnalogueClock();
            this.analogueClock3 = new GHNet.Windows.Forms.AnalogueClock();
            this.analogueClock2 = new GHNet.Windows.Forms.AnalogueClock();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock2)).BeginInit();
            this.SuspendLayout();
            // 
            // analogueClock1
            // 
            this.analogueClock1.ForeColor = System.Drawing.Color.CadetBlue;
            this.analogueClock1.Location = new System.Drawing.Point(6, 19);
            this.analogueClock1.Name = "analogueClock1";
            this.analogueClock1.Size = new System.Drawing.Size(137, 134);
            this.analogueClock1.StretchStyleImage = true;
            this.analogueClock1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.analogueClock6);
            this.groupBox1.Controls.Add(this.analogueClock5);
            this.groupBox1.Controls.Add(this.analogueClock4);
            this.groupBox1.Controls.Add(this.analogueClock3);
            this.groupBox1.Controls.Add(this.analogueClock2);
            this.groupBox1.Controls.Add(this.analogueClock1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(441, 315);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Analogue Clock";
            // 
            // analogueClock6
            // 
            this.analogueClock6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.analogueClock6.Location = new System.Drawing.Point(292, 170);
            this.analogueClock6.Name = "analogueClock6";
            this.analogueClock6.Size = new System.Drawing.Size(137, 134);
            this.analogueClock6.StretchStyleImage = true;
            this.analogueClock6.StyleImage = global::Clock.Properties.Resources.AC_Trad__135_135px_;
            this.analogueClock6.TabIndex = 5;
            // 
            // analogueClock5
            // 
            this.analogueClock5.Location = new System.Drawing.Point(149, 159);
            this.analogueClock5.Name = "analogueClock5";
            this.analogueClock5.Size = new System.Drawing.Size(137, 134);
            this.analogueClock5.StretchStyleImage = true;
            this.analogueClock5.StyleImage = global::Clock.Properties.Resources.AC_System__135_135px_;
            this.analogueClock5.TabIndex = 4;
            // 
            // analogueClock4
            // 
            this.analogueClock4.Location = new System.Drawing.Point(6, 159);
            this.analogueClock4.Name = "analogueClock4";
            this.analogueClock4.Size = new System.Drawing.Size(137, 134);
            this.analogueClock4.StretchStyleImage = true;
            this.analogueClock4.StyleImage = global::Clock.Properties.Resources.AC_Square__135_135px_;
            this.analogueClock4.TabIndex = 3;
            // 
            // analogueClock3
            // 
            this.analogueClock3.Location = new System.Drawing.Point(292, 19);
            this.analogueClock3.Name = "analogueClock3";
            this.analogueClock3.Size = new System.Drawing.Size(137, 197);
            this.analogueClock3.StretchStyleImage = true;
            this.analogueClock3.StyleImage = global::Clock.Properties.Resources.AC_Novelty__123_173px_;
            this.analogueClock3.TabIndex = 2;
            // 
            // analogueClock2
            // 
            this.analogueClock2.Location = new System.Drawing.Point(149, 19);
            this.analogueClock2.Name = "analogueClock2";
            this.analogueClock2.Size = new System.Drawing.Size(137, 134);
            this.analogueClock2.StretchStyleImage = true;
            this.analogueClock2.StyleImage = global::Clock.Properties.Resources.AC_Modern__135_135px_;
            this.analogueClock2.TabIndex = 1;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(469, 353);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analogueClock2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GHNet.Windows.Forms.AnalogueClock analogueClock1;
        private System.Windows.Forms.GroupBox groupBox1;
        private GHNet.Windows.Forms.AnalogueClock analogueClock3;
        private GHNet.Windows.Forms.AnalogueClock analogueClock2;
        private GHNet.Windows.Forms.AnalogueClock analogueClock6;
        private GHNet.Windows.Forms.AnalogueClock analogueClock5;
        private GHNet.Windows.Forms.AnalogueClock analogueClock4;
    }
}

