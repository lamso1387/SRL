﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RoyalMailSenderClass;

namespace WindowsFormsApplication5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MailSender ms = new MailSender("Your SMTP", "Your Webmail", "Your Username", "Your Password");
            string body = ms.Send(txtsubject.Text, txtto.Text, txtbody.Text, txtfrom.Text, txtname.Text);
            MessageBox.Show("پیام فرستاده شد", "توجه", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtfrom.Select();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtbody.SelectionAlignment = HorizontalAlignment.Right;
            txtbody.Select();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtbody.SelectionAlignment = HorizontalAlignment.Left;
            txtbody.Select();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            txtbody.SelectionAlignment = HorizontalAlignment.Center;
            txtbody.Select();
        }

     

    }
}
